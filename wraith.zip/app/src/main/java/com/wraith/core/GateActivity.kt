package com.wraith.core

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

class GateActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            var hasOverlay by remember { mutableStateOf(canDrawOverlays()) }

            Box(
                Modifier.fillMaxSize().background(Color(0xFF0A0A0D)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("WRAITH", color = Color(0xFFE8392D), style = MaterialTheme.typography.headlineMedium)
                    Text("Чит для Oxide: Survival Island", color = Color(0xFF8A8A92))
                    Spacer(Modifier.height(24.dp))
                    if (!hasOverlay) {
                        Button(
                            onClick = {
                                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE8392D))
                        ) { Text("Разрешить оверлей") }
                    } else {
                        Button(
                            onClick = {
                                startForegroundService(Intent(this@GateActivity, OverlayService::class.java))
                                moveTaskToBack(true)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE8392D))
                        ) { Text("Запустить") }
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        recreateIfPermissionChanged()
    }

    private fun recreateIfPermissionChanged() { /* state re-checked via compose on resume */ }

    private fun canDrawOverlays(): Boolean =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) Settings.canDrawOverlays(this) else true
}
