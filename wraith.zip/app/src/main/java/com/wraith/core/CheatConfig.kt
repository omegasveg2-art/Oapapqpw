package com.wraith.core

import android.content.Context
import com.google.gson.Gson
import java.io.File

enum class Tab(val label: String) {
    AIMBOT("Аим Бот"),
    SILENT("Сайлент Аим"),
    WORLD("Мир"),
    INFO("Инфо"),
    ESP("ESP"),
    WEAPON("Оружие"),
    BUILD("Строительство"),
}

enum class AimTarget(val label: String) {
    NEAREST("Ближайший враг"),
    CROSSHAIR("Под прицелом"),
    LOWEST_HP("Меньше всего HP"),
}

data class CheatConfig(
    var masterEnabled: Boolean = false,

    // AimBot
    var aimBotEnabled: Boolean = false,
    var aimAutoFire: Boolean = false,
    var aimFov: Float = 120f,
    var aimSmoothing: Float = 10f,
    var aimDelayMs: Int = 0,
    var aimTarget: AimTarget = AimTarget.NEAREST,

    // Silent Aim
    var silentAimEnabled: Boolean = false,
    var silentFov: Float = 180f,
    var silentHitChance: Float = 100f,
    var silentBone: String = "Голова",

    // World
    var noRecoil: Boolean = false,
    var noSpread: Boolean = false,
    var speedHack: Boolean = false,
    var speedMultiplier: Float = 1.5f,
    var noFall: Boolean = false,
    var nightVision: Boolean = false,

    // ESP
    var espPlayers: Boolean = false,
    var espAnimals: Boolean = false,
    var espLoot: Boolean = false,
    var espDistance: Boolean = false,
    var espHealth: Boolean = false,
    var espBoxes: Boolean = false,
    var espSkeleton: Boolean = false,
    var espMaxDistance: Float = 500f,

    // Weapon
    var infiniteAmmo: Boolean = false,
    var noReload: Boolean = false,
    var oneHitKill: Boolean = false,

    // Building
    var noBuildCollision: Boolean = false,
    var instantUpgrade: Boolean = false,
    var freeBuild: Boolean = false,
) {
    companion object {
        private const val FILE = "wraith_config.json"

        fun load(ctx: Context): CheatConfig {
            val f = File(ctx.filesDir, FILE)
            if (!f.exists()) return CheatConfig()
            return try {
                Gson().fromJson(f.readText(), CheatConfig::class.java) ?: CheatConfig()
            } catch (e: Exception) {
                CheatConfig()
            }
        }
    }

    fun save(ctx: Context) {
        File(ctx.filesDir, FILE).writeText(Gson().toJson(this))
    }
}
