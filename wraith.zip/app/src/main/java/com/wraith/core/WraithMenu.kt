package com.wraith.core

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val bg = Color(0xFF0A0A0D)
private val panel = Color(0xFF121216)
private val red = Color(0xFFE8392D)
private val redDim = Color(0xFF7A1F18)
private val txt = Color(0xFFEDEDED)
private val txtDim = Color(0xFF8A8A92)
private val onCol = Color(0xFF39E86B)

@Composable
fun WraithMenu(
    config: CheatConfig,
    onConfigChanged: (CheatConfig) -> Unit,
    onClose: () -> Unit,
    onMinimize: () -> Unit,
) {
    var tab by remember { mutableStateOf(Tab.AIMBOT) }
    var cfg by remember { mutableStateOf(config) }
    fun update(block: CheatConfig.() -> Unit) {
        val copy = cfg.copy()
        copy.block()
        cfg = copy
        onConfigChanged(copy)
    }

    Column(
        modifier = Modifier
            .width(620.dp)
            .heightIn(max = 460.dp)
            .background(bg, RoundedCornerShape(10.dp))
            .border(1.dp, Color(0xFF2A2A30), RoundedCornerShape(10.dp))
    ) {
        // Header
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .background(panel, RoundedCornerShape(topStart = 10.dp, topEnd = 10.dp))
                .padding(horizontal = 16.dp, vertical = 10.dp)
        ) {
            Box(
                Modifier
                    .size(34.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(redDim),
                contentAlignment = Alignment.Center
            ) { Text("W", color = red, fontWeight = FontWeight.Bold, fontSize = 18.sp) }
            Spacer(Modifier.width(10.dp))
            Column {
                Text("WRAITH", color = txt, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text("Чит для Oxide: Survival Island", color = txtDim, fontSize = 11.sp)
            }
            Spacer(Modifier.weight(1f))
            val statusColor = if (cfg.masterEnabled) onCol else txtDim
            val statusText = if (cfg.masterEnabled) "Включен" else "Выключен"
            Text("Статус: ", color = txtDim, fontSize = 12.sp)
            Text(statusText, color = statusColor, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(14.dp))
            IconText("—", onMinimize)
            Spacer(Modifier.width(10.dp))
            IconText("✕", onClose)
        }

        Row(Modifier.fillMaxWidth().weight(1f, fill = false)) {
            // Sidebar
            Column(
                Modifier
                    .width(170.dp)
                    .fillMaxHeight()
                    .background(panel)
                    .padding(vertical = 8.dp)
            ) {
                Tab.values().forEach { t ->
                    SidebarItem(t, selected = tab == t) { tab = t }
                }
                Spacer(Modifier.weight(1f))
                Column(Modifier.padding(start = 16.dp, bottom = 10.dp)) {
                    Text("WRAITH", color = red, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text("v1.0.0", color = txtDim, fontSize = 10.sp)
                }
            }

            // Content
            Column(
                Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(18.dp)
            ) {
                when (tab) {
                    Tab.AIMBOT -> AimBotPanel(cfg, ::update)
                    Tab.SILENT -> SilentAimPanel(cfg, ::update)
                    Tab.WORLD -> WorldPanel(cfg, ::update)
                    Tab.INFO -> InfoPanel()
                    Tab.ESP -> EspPanel(cfg, ::update)
                    Tab.WEAPON -> WeaponPanel(cfg, ::update)
                    Tab.BUILD -> BuildPanel(cfg, ::update)
                }
            }
        }
    }
}

@Composable
private fun IconText(s: String, onClick: () -> Unit) {
    Box(Modifier.size(26.dp).clip(RoundedCornerShape(6.dp)).clickable { onClick() }, contentAlignment = Alignment.Center) {
        Text(s, color = txtDim, fontSize = 14.sp)
    }
}

@Composable
private fun SidebarItem(tab: Tab, selected: Boolean, onClick: () -> Unit) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .background(if (selected) red else Color.Transparent)
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        Text(tabIcon(tab), fontSize = 14.sp)
        Spacer(Modifier.width(10.dp))
        Text(tab.label, color = if (selected) Color.White else txt, fontSize = 13.sp)
    }
}

private fun tabIcon(t: Tab) = when (t) {
    Tab.AIMBOT -> "◎"
    Tab.SILENT -> "✕"
    Tab.WORLD -> "⊕"
    Tab.INFO -> "ⓘ"
    Tab.ESP -> "◉"
    Tab.WEAPON -> "⚒"
    Tab.BUILD -> "⚙"
}

@Composable
private fun SectionTitle(title: String, subtitle: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(tabIconBySection(title), fontSize = 16.sp, color = red)
        Spacer(Modifier.width(8.dp))
        Column {
            Text(title, color = txt, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Text(subtitle, color = txtDim, fontSize = 11.sp)
        }
    }
    Spacer(Modifier.height(14.dp))
}

private fun tabIconBySection(title: String) = "◎"

@Composable
private fun ToggleRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = txt, fontSize = 13.sp, modifier = Modifier.weight(1f))
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedTrackColor = red,
                checkedThumbColor = Color.White,
                uncheckedTrackColor = Color(0xFF2A2A30),
                uncheckedThumbColor = txtDim,
            )
        )
    }
}

@Composable
private fun SliderRow(label: String, value: Float, range: ClosedFloatingPointRange<Float>, unit: String, onChange: (Float) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        Row(Modifier.fillMaxWidth()) {
            Text(label, color = txt, fontSize = 13.sp, modifier = Modifier.weight(1f))
            Text("${value.toInt()}$unit", color = red, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
        Slider(
            value = value, onValueChange = onChange, valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = red, activeTrackColor = red, inactiveTrackColor = Color(0xFF2A2A30)
            )
        )
    }
}

@Composable
private fun AimBotPanel(cfg: CheatConfig, update: ((CheatConfig.() -> Unit)) -> Unit) {
    SectionTitle("Аим Бот", "Умное прицеливание на врагов")
    ToggleRow("Включить Аим Бот", cfg.aimBotEnabled) { v -> update { aimBotEnabled = v } }
    ToggleRow("Авто Выстрел", cfg.aimAutoFire) { v -> update { aimAutoFire = v } }
    SliderRow("FOV (Угол захвата)", cfg.aimFov, 10f..180f, "°") { v -> update { aimFov = v } }
    SliderRow("Скорость наводки", cfg.aimSmoothing, 1f..30f, "") { v -> update { aimSmoothing = v } }
    SliderRow("Задержка (мс)", cfg.aimDelayMs.toFloat(), 0f..500f, "") { v -> update { aimDelayMs = v.toInt() } }
    Spacer(Modifier.height(6.dp))
    Text("Выберите цель: ${cfg.aimTarget.label}", color = txtDim, fontSize = 12.sp)
}

@Composable
private fun SilentAimPanel(cfg: CheatConfig, update: ((CheatConfig.() -> Unit)) -> Unit) {
    SectionTitle("Сайлент Аим", "Попадание без поворота камеры")
    ToggleRow("Включить Сайлент Аим", cfg.silentAimEnabled) { v -> update { silentAimEnabled = v } }
    SliderRow("FOV захвата", cfg.silentFov, 10f..360f, "°") { v -> update { silentFov = v } }
    SliderRow("Шанс попадания", cfg.silentHitChance, 1f..100f, "%") { v -> update { silentHitChance = v } }
    Text("Точка попадания: ${cfg.silentBone}", color = txtDim, fontSize = 12.sp)
}

@Composable
private fun WorldPanel(cfg: CheatConfig, update: ((CheatConfig.() -> Unit)) -> Unit) {
    SectionTitle("Мир", "Движение и физика")
    ToggleRow("Без отдачи (No Recoil)", cfg.noRecoil) { v -> update { noRecoil = v } }
    ToggleRow("Без разброса (No Spread)", cfg.noSpread) { v -> update { noSpread = v } }
    ToggleRow("Ускорение", cfg.speedHack) { v -> update { speedHack = v } }
    SliderRow("Множитель скорости", cfg.speedMultiplier, 1f..5f, "x") { v -> update { speedMultiplier = v } }
    ToggleRow("Без урона от падения", cfg.noFall) { v -> update { noFall = v } }
    ToggleRow("Ночное видение", cfg.nightVision) { v -> update { nightVision = v } }
}

@Composable
private fun InfoPanel() {
    SectionTitle("Инфо", "О чите")
    Text("WRAITH v1.0.0", color = txt, fontSize = 13.sp)
    Spacer(Modifier.height(6.dp))
    Text("Внешний чит, только чтение памяти. Без инъекций в процесс игры.", color = txtDim, fontSize = 12.sp)
    Spacer(Modifier.height(10.dp))
    Text("Сборка под Oxide: Survival Island (il2cpp). Офсеты актуальны на момент сборки и могут слететь после патча игры.", color = txtDim, fontSize = 12.sp)
}

@Composable
private fun EspPanel(cfg: CheatConfig, update: ((CheatConfig.() -> Unit)) -> Unit) {
    SectionTitle("ESP", "Видеть сквозь стены")
    ToggleRow("Игроки", cfg.espPlayers) { v -> update { espPlayers = v } }
    ToggleRow("Животные/зомби", cfg.espAnimals) { v -> update { espAnimals = v } }
    ToggleRow("Лут", cfg.espLoot) { v -> update { espLoot = v } }
    ToggleRow("Дистанция", cfg.espDistance) { v -> update { espDistance = v } }
    ToggleRow("Здоровье", cfg.espHealth) { v -> update { espHealth = v } }
    ToggleRow("Боксы", cfg.espBoxes) { v -> update { espBoxes = v } }
    ToggleRow("Скелет", cfg.espSkeleton) { v -> update { espSkeleton = v } }
    SliderRow("Макс. дистанция", cfg.espMaxDistance, 50f..2000f, "м") { v -> update { espMaxDistance = v } }
}

@Composable
private fun WeaponPanel(cfg: CheatConfig, update: ((CheatConfig.() -> Unit)) -> Unit) {
    SectionTitle("Оружие", "Патроны и урон")
    ToggleRow("Бесконечные патроны", cfg.infiniteAmmo) { v -> update { infiniteAmmo = v } }
    ToggleRow("Без перезарядки", cfg.noReload) { v -> update { noReload = v } }
    ToggleRow("Урон с одного попадания", cfg.oneHitKill) { v -> update { oneHitKill = v } }
}

@Composable
private fun BuildPanel(cfg: CheatConfig, update: ((CheatConfig.() -> Unit)) -> Unit) {
    SectionTitle("Строительство", "Постройка без ограничений")
    ToggleRow("Без коллизии построек", cfg.noBuildCollision) { v -> update { noBuildCollision = v } }
    ToggleRow("Мгновенный апгрейд", cfg.instantUpgrade) { v -> update { instantUpgrade = v } }
    ToggleRow("Строить где угодно", cfg.freeBuild) { v -> update { freeBuild = v } }
}
